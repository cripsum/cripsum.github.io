
# 🖥️ Site Rich Presence – Personal Discord RPC



Questo programma aggiorna automaticamente la tua **Rich Presence Discord** in base a cosa stai facendo sul sito **cripsum.com**.



---



## ⚙️ Come si usa



1. **Crea un'app su Discord Developer Portal**  

&nbsp;  Vai qui: [https://discord.com/developers/applications](https://discord.com/developers/applications)



&nbsp;  ➜ Clicca **“New Application”**  

&nbsp;  ➜ Dagli il nome cripsum.com  

&nbsp;  ➜ Premi **Create**



2. **Trova il tuo Client ID**



&nbsp;  Dopo aver creato l’app, rimarrai nella pagina delle **impostazioni generali**.  

&nbsp;  Cerca la voce **APPLICATION ID** e premi l’icona di copia 📋 accanto.



3. **Apri la cartella del programma**



4. **Apri o crea il file `client_id.txt`**



5. **Scrivici dentro così:**



il_tuo_id_discord=1234567890



🔁 Sostituisci il numero con il tuo vero **Client ID**



6. **Avvia il file `richpresence.exe`**



7. Lascia l’app aperta mentre navighi sul sito. La presenza si aggiornerà da sola 🧠



---



## ❓ Problemi comuni



- Si chiude subito?  

➜ Controlla che `client_id.txt` sia scritto nel modo giusto (niente spazi strani, niente virgolette).



- Non compare nulla su Discord?  

➜ Assicurati che:

- Discord sia **aperto**

- Il Client ID sia corretto

- L'app sia **tua** (non puoi usare l’ID di qualcun altro)



- Usi più versioni di Discord (PTB, Canary)?  

➜ Apri solo quella su cui vuoi vedere la Rich Presence.



---



## ✉️ Info



Creato da [@cripsum](https://cripsum.com)  

Nessun dato viene inviato a server esterni. Tutto resta in locale.



